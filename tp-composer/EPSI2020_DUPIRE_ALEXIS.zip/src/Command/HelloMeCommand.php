<?php


namespace App\Command;


use Symfony\Component\Console\Command\Command;

class HelloMeCommand extends Command
{

}